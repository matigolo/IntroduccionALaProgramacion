package aed;

public class Recordatorio {

    private String _mensaje;
    private Fecha _fecha;
    private Horario _horario;



    // Recordatorio es mi constructor
    public Recordatorio(String mensaje, Fecha fecha, Horario horario) {
        _mensaje = mensaje;
        _fecha = new Fecha(fecha);
        _horario = horario;
    }

    public Horario horario() {
        // Implementar
        return _horario;
    }

    public Fecha fecha() {
        // Implementar
        return new Fecha(_fecha);
    }

    public String mensaje() {
        // Implementar
        return _mensaje;
    }

    @Override
    public String toString() {
        // Implementar
        return _mensaje + " @ " + _fecha + " " + _horario;
    }

    @Override
    public boolean equals(Object otro) {
        boolean otroEsNull = (otro == null);
        if (otroEsNull){
            return false;
        }
        boolean claseDistinta = otro.getClass() != this.getClass();
        if (claseDistinta){
            return false;
        }

        Recordatorio otroRecordatorio = (Recordatorio) otro;

        return _mensaje == otroRecordatorio._mensaje && _horario == otroRecordatorio._horario && _fecha == otroRecordatorio._fecha;


    }

}
