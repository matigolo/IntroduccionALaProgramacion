package aed;

public class Horario {
    private int _hora;
    private int _minutos;
    //este es mi constructor horario
    public Horario(int hora, int minutos) {
        _hora = hora;
        _minutos = minutos;
    }

    public int hora() {
        // Implementar
        return _hora;
    }

    public int minutos() {
        // Implementar
        return _minutos;
    }

    @Override
    public String toString() {
        // Implementar
        return _hora + ":" + _minutos;
    }

    @Override
    public boolean equals(Object otro) {
        boolean otroEsNull = (otro == null);
        if (otroEsNull){
            return false;
        }
        boolean claseDistinta = otro.getClass() != this.getClass();
        if (claseDistinta){
            return false;
        }
        Horario otroHorario = (Horario) otro;
        return _hora == otroHorario._hora && _minutos == otroHorario._minutos;
    }

}
