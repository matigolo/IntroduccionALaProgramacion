package aed;

class ArregloRedimensionableDeRecordatorios {



    //este es mi constructor
    public ArregloRedimensionableDeRecordatorios() {
        // Implementar
    }

    public int longitud() {
        return -1;
    }

    public void agregarAtras(Recordatorio i) {
        // Implementar
    }

    public Recordatorio obtener(int i) {
        // Implementar
        return null;
    }

    public void quitarAtras() {
        // Implementar
    }

    public void modificarPosicion(int indice, Recordatorio valor) {
        // Implementar
    }

    public ArregloRedimensionableDeRecordatorios(ArregloRedimensionableDeRecordatorios vector) {
        // Implementar
    }

    public ArregloRedimensionableDeRecordatorios copiar() {
        // Implementar
        return null;
    }
}
